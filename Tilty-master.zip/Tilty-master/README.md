
TILTY - mobile app to keep your device level while physically jostling other players!

This repository is for the Dan Zen mobile app made with ZIM http://zimjs.com

ZIM is an open source JavaScript Canvas Framework - with lots of cool stuff
and oodles of examples, tutorials, lessons, and docs.

Tilty is a follow up to Touchy - also made with ZIM for iOS and Android.

We are doing a video capture documentary on this procedure.

We will update links to the videos as we publish them on the ZIM Learn YouTube Channel

https://www.youtube.com/c/zimlearn

The steps for publishing (ala 2014-2017) are provided as is in the repository

As are a pair of Photoshop scripts for making icons and splash pages

And a diagram of the iOS publishing system.

Dan Zen

http://danzen.com
